import java.util.*;

class SimpleNode {
    private int id;
    private boolean active;
    private boolean isCoordinator;
    private List<SimpleNode> allNodes;

    public SimpleNode(int id) {
        this.id = id;
        this.active = true;
        this.isCoordinator = false;
        this.allNodes = new ArrayList<>();
    }

    public void setAllNodes(List<SimpleNode> nodes) {
        this.allNodes = nodes;
    }

    public void startElection() {
        if (!active) {
            System.out.println("Node " + id + " is inactive. Cannot start election.");
            return;
        }

        System.out.println("Node " + id + " is starting an election...");

        boolean foundHigherNode = false;

        // Send election message to all higher nodes
        for (SimpleNode node : allNodes) {

            if (node.id > this.id && node.isActive()) {
                System.out.println("Node " + id + " sends election message to Node " + node.id);
                foundHigherNode = true;

                // Simulate higher node responding by starting its own election
                if (node.isActive()) {
                    node.startElection();
                    return; // This node stops its election since higher node responded
                }
            }
        }

        // If no higher active nodes found, declare myself as coordinator
        if (!foundHigherNode) {
            declareAsCoordinator();
        }
    }

    private void declareAsCoordinator() {
        this.isCoordinator = true;
        System.out.println("✔ Node " + id + " is now the COORDINATOR!");

        // Announce to all other nodes
        for (SimpleNode node : allNodes) {
            if (node.id != this.id && node.isActive()) {
                System.out.println("Node " + id + " announces as coordinator to Node " + node.id);
                node.setCoordinator(false); // Other nodes are not coordinator
            }
        }
    }

    public void fail() {
        if (isCoordinator) {
            System.out.println("❌ Coordinator Node " + id + " has failed!");
            isCoordinator = false;
        }
        this.active = false;
    }

    public void recover() {
        this.active = true;
        System.out.println("✅ Node " + id + " has recovered");
    }

    // Getters
    public int getId() { return id; }
    public boolean isActive() { return active; }
    public boolean isCoordinator() { return isCoordinator; }
    public void setCoordinator(boolean coordinator) { this.isCoordinator = coordinator; }
}
