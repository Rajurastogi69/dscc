import java.util.*;

public class VerySimpleElection {

    static class Node {
        int id;
        boolean active = true;
        boolean isCoordinator = false;

        Node(int id) { 
            this.id = id; 
        }
    }

    static List<Node> nodes = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        // Create 5 nodes
        for (int i = 1; i <= 5; i++) {
            nodes.add(new Node(i));
        }

        nodes.get(4).isCoordinator = true; // Node 5 is initial coordinator

        System.out.println("🟢 Simple Election Algorithm Demo");
        System.out.println(" (5 nodes: 1,2,3,4,5 | Node 5 starts as coordinator)");

        while (true) {

            System.out.println("\n--- Menu ---");
            System.out.println("1. Show Status");
            System.out.println("2. Start Election");
            System.out.println("3. Fail Node");
            System.out.println("4. Recover Node");
            System.out.println("5. Exit");
            System.out.print("Choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1: showStatus(); break;
                case 2: startElection(); break;
                case 3: failNode(); break;
                case 4: recoverNode(); break;
                case 5:
                    System.out.println("Bye!");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    static void showStatus() {
        System.out.println("\nNode Status:");
        for (Node node : nodes) {
            String status = node.active ?
                (node.isCoordinator ? "COORDINATOR" : "Active") :
                "Failed";
            System.out.println("Node " + node.id + ": " + status);
        }
    }

    static void startElection() {
        System.out.print("Start election from which node? (1-5): ");
        int startId = sc.nextInt();

        if (startId < 1 || startId > 5) {
            System.out.println("Invalid node!");
            return;
        }

        Node starter = nodes.get(startId - 1);

        if (!starter.active) {
            System.out.println("Node is failed!");
            return;
        }

        System.out.println("Node " + startId + " starts election...");

        // Simple bully algorithm: highest active node wins
        Node newCoordinator = null;

        for (int i = nodes.size() - 1; i >= 0; i--) {
            if (nodes.get(i).active) {
                newCoordinator = nodes.get(i);
                break;
            }
        }

        if (newCoordinator != null) {
            // Remove coordinator role from all nodes
            for (Node node : nodes) {
                node.isCoordinator = false;
            }
            newCoordinator.isCoordinator = true;
            System.out.println("🏆 Node " + newCoordinator.id + " elected as NEW COORDINATOR!");
        }
    }

    static void failNode() {
        System.out.print("Fail which node? (1-5): ");
        int nodeId = sc.nextInt();

        if (nodeId < 1 || nodeId > 5) {
            System.out.println("Invalid node!");
            return;
        }

        Node node = nodes.get(nodeId - 1);

        if (!node.active) {
            System.out.println("Node already failed!");
            return;
        }

        node.active = false;
        boolean wasCoordinator = node.isCoordinator;
        node.isCoordinator = false;

        System.out.println("❌ Node " + nodeId + " failed!");

        if (wasCoordinator) {
            System.out.println("Coordinator failed! Auto-starting election...");

            Node newCoordinator = null;
            for (int i = nodes.size() - 1; i >= 0; i--) {
                if (nodes.get(i).active) {
                    newCoordinator = nodes.get(i);
                    break;
                }
            }

            if (newCoordinator != null) {
                newCoordinator.isCoordinator = true;
                System.out.println("🏆 Node " + newCoordinator.id + " elected as NEW COORDINATOR!");
            } else {
                System.out.println("❌ All nodes failed! No coordinator available.");
            }
        }
    }

    static void recoverNode() {
        System.out.print("Recover which node? (1-5): ");
        int nodeId = sc.nextInt();

        if (nodeId < 1 || nodeId > 5) {
            System.out.println("Invalid node!");
            return;
        }

        Node node = nodes.get(nodeId - 1);

        if (node.active) {
            System.out.println("Node already active!");
            return;
        }

        node.active = true;
        System.out.println("✅ Node " + nodeId + " recovered!");
    }
}
