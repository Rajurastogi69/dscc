import java.util.*;

public class SimpleElectionSystem {
    private List<SimpleNode> nodes;
    private Scanner scanner;

    public SimpleElectionSystem() {
        this.nodes = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        initializeNodes();
    }

    private void initializeNodes() {
        // Create 5 nodes
        for (int i = 1; i <= 5; i++) {
            nodes.add(new SimpleNode(i));
        }

        // Set the reference to all nodes for each node
        for (SimpleNode node : nodes) {
            node.setAllNodes(nodes);
        }

        // Initially, node 5 is the coordinator
        nodes.get(4).setCoordinator(true);
    }

    public void displayStatus() {
        System.out.println("\n=== SYSTEM STATUS ===");
        for (SimpleNode node : nodes) {
            String status = node.isActive() ?
                    (node.isCoordinator() ? "COORDINATOR" : "Active") : "Failed";
            System.out.println("Node " + node.getId() + ": " + status);
        }
        System.out.println("=====================\n");
    }

    public void startElectionFromNode(int nodeId) {
        SimpleNode node = findNode(nodeId);
        if (node != null && node.isActive()) {
            node.startElection();
        } else {
            System.out.println("Node " + nodeId + " is not active or doesn't exist");
        }
    }

    public void failNode(int nodeId) {
        SimpleNode node = findNode(nodeId);
        if (node != null) {
            node.fail();

            // If coordinator failed, automatically start election from highest active node
            if (node.isCoordinator()) {
                System.out.println("Coordinator failed! Starting election automatically...");
                startElectionFromHighestActiveNode();
            }
        }
    }

    public void recoverNode(int nodeId) {
        SimpleNode node = findNode(nodeId);
        if (node != null) {
            node.recover();
        }
    }

    private void startElectionFromHighestActiveNode() {
        // Find the highest active node and start election from there
        for (int i = nodes.size() - 1; i >= 0; i--) {
            SimpleNode node = nodes.get(i);
            if (node.isActive()) {
                node.startElection();
                break;
            }
        }
    }

    private SimpleNode findNode(int nodeId) {
        for (SimpleNode node : nodes) {
            if (node.getId() == nodeId) {
                return node;
            }
        }
        return null;
    }

    public void run() {
        System.out.println("   Simplified Election Algorithm (Bully Algorithm)");
        System.out.println("==================================================");

        while (true) {
            System.out.println("\nCommands:");
            System.out.println("1. status - Show node status");
            System.out.println("2. elect <node> - Start election from node");
            System.out.println("3. fail <node> - Fail a node");
            System.out.println("4. recover <node> - Recover a node");
            System.out.println("5. quit - Exit");
            System.out.print("Enter command: ");

            String input = scanner.nextLine().trim();
            String[] parts = input.split(" ");

            if (parts.length == 0) continue;

            String command = parts[0].toLowerCase();

            switch (command) {
                case "status":
                    displayStatus();
                    break;

                case "elect":
                    if (parts.length > 1) {
                        try {
                            int nodeId = Integer.parseInt(parts[1]);
                            startElectionFromNode(nodeId);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid node ID");
                        }
                    }
                    break;

                case "fail":
                    if (parts.length > 1) {
                        try {
                            int nodeId = Integer.parseInt(parts[1]);
                            failNode(nodeId);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid node ID");
                        }
                    }
                    break;

                case "recover":
                    if (parts.length > 1) {
                        try {
                            int nodeId = Integer.parseInt(parts[1]);
                            recoverNode(nodeId);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid node ID");
                        }
                    }
                    break;

                case "quit":
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Unknown command");
            }
        }
    }

    public static void main(String[] args) {
        SimpleElectionSystem system = new SimpleElectionSystem();
        system.run();
    }
}
