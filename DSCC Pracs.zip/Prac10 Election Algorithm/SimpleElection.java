import java.util.*;

public class SimpleElection {
    public static void main(String[] args) {

        // Create nodes
        SimpleNode n1 = new SimpleNode(1);
        SimpleNode n2 = new SimpleNode(2);
        SimpleNode n3 = new SimpleNode(3);
        SimpleNode n4 = new SimpleNode(4);
        SimpleNode n5 = new SimpleNode(5);

        // Add all nodes to list
        List<SimpleNode> nodes = new ArrayList<>();
        nodes.add(n1);
        nodes.add(n2);
        nodes.add(n3);
        nodes.add(n4);
        nodes.add(n5);

        // Assign list to all nodes
        for (SimpleNode n : nodes) {
            n.setAllNodes(nodes);
        }

        // Start election from node 2 (you can choose anyone)
        n2.startElection();
    }
}
