import java.io.*;
import java.net.*;
import java.util.*;

public class ClientRPC {
    public static void main(String[] args) {
        try {
            Socket s = new Socket("localhost", 5000);
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);

            Scanner sc = new Scanner(System.in);

            while (true) {
                System.out.print("Enter Operation (add/sub/mul/div) or exit: ");
                String op = sc.nextLine();
                pw.println(op);

                if (op.equalsIgnoreCase("exit"))
                    break;

                System.out.print("Enter first number: ");
                pw.println(sc.nextLine());

                System.out.print("Enter second number: ");
                pw.println(sc.nextLine());

                String result = br.readLine();
                System.out.println("Server Reply: " + result);
            }

            s.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
