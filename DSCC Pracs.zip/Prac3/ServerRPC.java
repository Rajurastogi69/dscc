import java.io.*;
import java.net.*;

public class ServerRPC {
    public static void main(String[] args) {
        try {
            ServerSocket ss = new ServerSocket(5000);
            System.out.println("Server Started... Waiting for Client");

            Socket s = ss.accept();
            System.out.println("Client Connected.");

            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);

            while (true) {
                String operation = br.readLine();
                if (operation.equalsIgnoreCase("exit")) {
                    System.out.println("Client Disconnected.");
                    break;
                }

                double a = Double.parseDouble(br.readLine());
                double b = Double.parseDouble(br.readLine());
                double result = 0;

                switch (operation.toLowerCase()) {
                    case "add": result = a + b; break;
                    case "sub": result = a - b; break;
                    case "mul": result = a * b; break;
                    case "div":
                        if (b == 0) {
                            pw.println("Error: Division by zero!");
                            continue;
                        }
                        result = a / b;
                        break;
                    default:
                        pw.println("Invalid Operation");
                        continue;
                }

                pw.println("Result = " + result);
            }

            s.close();
            ss.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
