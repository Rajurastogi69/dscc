import java.net.*;
public class TokenRingServer
{
public static DatagramSocket ds;
public static DatagramPacket dp;
public static void main(String[] args)throws Exception
{
ds = new DatagramSocket(2000);
while(true)
{ byte[] buffer = new byte[1024];

dp=new DatagramPacket(buffer,buffer.length);
ds.receive(dp);
String msg=new String(dp.getData(),0,dp.getLength());
System.out.println("Message from:"+msg);

} } }