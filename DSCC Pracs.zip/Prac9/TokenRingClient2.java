import java.net.*;
import java.io.*;
public class TokenRingClient2
{
public static DatagramSocket ds;
public static DatagramPacket dp;
public static BufferedReader br;
public static void main(String[] args)throws Exception
{
boolean hasToken = true;
ds = new DatagramSocket(2002);
while(true)
{
if(hasToken==true)
{
System.out.println("Do you want to Enter CS? (yes/no): ");
br=new BufferedReader(new InputStreamReader(System.in));
String choice =br.readLine();
if(choice.equalsIgnoreCase("yes"))
{
System.out.println("The Client/Process is Ready to Write");
System.out.println("Enter the Message: ");
br=new BufferedReader(new

InputStreamReader(System.in));

String msg = "Client1-->"+br.readLine();
dp=new

DatagramPacket(msg.getBytes(),msg.length(),InetAddress.getLocalHost(),2000);

ds.send(dp);
System.out.println("Message Sent");
}
else if(choice.equalsIgnoreCase("no"))
{
System.out.println("I am Not Ready to Enter the Critical Section");

String msg1="Token";
dp=new

DatagramPacket(msg1.getBytes(),msg1.length(),InetAddress.getLocalHost(),2003);

ds.send(dp);
hasToken=false;
} }
else
{
System.out.println("Waiting for Token");
byte[] buffer = new byte[2048];
dp=new DatagramPacket(buffer,buffer.length);
ds.receive(dp);
String prevProcessMsg=new String(dp.getData(),0,dp.getLength());
System.out.println("PreviousProcessMsg is "+prevProcessMsg);
if(prevProcessMsg.equals("Token"))
{
hasToken=true;
System.out.println("I have Token now");
}
} }

} }