import java.io.*;
import java.net.*;
import java.util.Scanner;

public class DateTimeClientRPC {

    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 5000);

            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter pw = new PrintWriter(socket.getOutputStream(), true);

            Scanner sc = new Scanner(System.in);

            while (true) {
                System.out.println("\nEnter RPC Request:");
                System.out.println("1. date");
                System.out.println("2. time");
                System.out.println("3. datetime");
                System.out.println("4. exit");
                System.out.print("Choice: ");

                String req = sc.nextLine();
                pw.println(req);

                if (req.equalsIgnoreCase("exit"))
                    break;

                String response = br.readLine();
                System.out.println("Server Response: " + response);
            }

            socket.close();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}
