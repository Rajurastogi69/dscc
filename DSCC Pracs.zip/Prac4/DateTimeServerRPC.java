import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeServerRPC {

    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(5000);
            System.out.println("Date-Time Server Started. Waiting for Client...");

            Socket socket = server.accept();
            System.out.println("Client Connected.");

            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter pw = new PrintWriter(socket.getOutputStream(), true);

            while (true) {
                String request = br.readLine();

                if (request == null || request.equalsIgnoreCase("exit")) {
                    System.out.println("Client Disconnected.");
                    break;
                }

                String response = handleRPCRequest(request);
                pw.println(response);
            }

            socket.close();
            server.close();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }

    public static String handleRPCRequest(String procedure) {
        Date now = new Date();

        switch (procedure.toLowerCase()) {

            case "date":
                return "Current Date: " + new SimpleDateFormat("dd-MM-yyyy").format(now);

            case "time":
                return "Current Time: " + new SimpleDateFormat("HH:mm:ss").format(now);

            case "datetime":
                return "Current Date & Time: " + new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(now);

            default:
                return "Invalid RPC Request!";
        }
    }
}
